#!/bin/bash

echo "_______________________________________________________________________________"
echo "██╗  ██╗██╗     ██╗     ███████╗██╗  ██╗███████╗██╗██████╗ ██╗██╗   ██╗███████╗"
echo "╚██╗██╔╝██║     ██║     ██╔════╝╚██╗██╔╝██╔════╝██║██╔══██╗██║██║   ██║██╔════╝"
echo " ╚███╔╝ ██║     ██║     █████╗   ╚███╔╝ ███████╗██║██║  ██║██║██║   ██║███████╗"
echo " ██╔██╗ ██║     ██║     ██╔══╝   ██╔██╗ ╚════██║██║██║  ██║██║██║   ██║╚════██║"
echo "██╔╝ ██╗███████╗███████╗███████╗██╔╝ ██╗███████║██║██████╔╝██║╚██████╔╝███████║"
echo "╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝╚═╝  ╚═╝╚══════╝╚═╝╚═════╝ ╚═╝ ╚═════╝ ╚══════╝"
echo "_______________________________________________________________________________"
                                                                               
  echo Script para Kali Linux

  echo Actualización de paquetes y del sistema operativo. También instalando programas necesarios para Kali Linux, AUTOR xllExsidius

  sleep 2s

  cd /home/xllExsidius

  sudo apt-get update

  sudo apt-get upgrade

  sudo apt-get install bettercap

  sudo apt-get install mdk4

  sudo apt-get install hostapd

  sudo apt-get install dhcpcd5

  sudo apt-get install hostapd-wpe 

  sudo apt-get install i3

  sudo apt-get install neofetch

  sudo apt-get install feh

  sudo apt-get install synaptic

  sudo apt-get install cbatticon

  sudo apt-get install parcellite

  mkdir RAT /home/xllExsidius

  cd /home/xllExsidius/RAT 

  git clone https://github.com/Screetsec/TheFatRat

  cd /home/xllExsidius/RAT/TheFatRat

  chmod +x setup.sh

  sudo ./setup.sh

  sleep 250s

  cd /home/xllExsidius

  rm -rf /home/xllExsidius/RAT

  mkdir /home/xllExsidius/Alien

  cd /home/xllExsidius/Alien

  git clone https://github.com/v1s1t0r1sh3r3/airgeddon

  cd binaries

  cd kali

  dpkg -i airgeddon_9.22-1_all.deb

  sleep 23s

  echo Actualización e instalación terminada... 

  sleep 5s
  
  echo Conectando a la Base de Datos Postgresql a Metasploit Framework...
  
  sleep 2s

  sudo /usr/bin/msfdb run

  sleep 2s

  echo Conexión éxitosa... 

  sleep 2s

  echo Gracias por usar mi script ";)"
  
  
