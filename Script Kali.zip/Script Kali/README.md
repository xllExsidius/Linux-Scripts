##############################################################################################################################
El Script hace actualización al sistema e instala algunos paquetes necesarios para Kali...

Recuerde de darle permisos con chmod +755 ó chmod +x, éste último es darle permiso a todos los usuarios y luego ejecutarlo con privilegio ROOT. Nos vemos ;) att:xllExsidius

##############################################################################################################################
